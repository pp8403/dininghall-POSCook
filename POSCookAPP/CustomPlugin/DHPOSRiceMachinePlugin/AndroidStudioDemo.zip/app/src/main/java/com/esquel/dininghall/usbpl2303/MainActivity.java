package com.esquel.dininghall.usbpl2303;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPreferences;
import org.apache.cordova.CordovaResourceApi;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.CordovaWebViewEngine;
import org.apache.cordova.ICordovaCookieManager;
import org.apache.cordova.PluginEntry;
import org.apache.cordova.PluginManager;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    DHPOSRiceMachinePlugin pl2303plugin=new DHPOSRiceMachinePlugin();


    TextView labMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pl2303plugin._activity=MainActivity.this;
        labMsg=(TextView)findViewById(R.id.labMsg);

        Button btnOpen=(Button)findViewById(R.id.btnOpen);
        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CallbackContext context=new CallbackContext("btnOpen",webView);

                JSONArray arg=new JSONArray();
                arg.put("Hi!");
                try {
                    pl2303plugin.execute("Open", arg, context);
                }catch (Exception e){
                    addMsg(e.getMessage());
                }

            }
        });
        Button btnSend=(Button)findViewById(R.id.btnSend);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CallbackContext context=new CallbackContext("SendCommon",webView);

                JSONArray arg=new JSONArray();
                arg.put("Hi!");
                try {
                    pl2303plugin.execute("SendCommon", arg, context);
                }catch (Exception e){
                    addMsg(e.getMessage());
                }
            }
        });

    }

    void addMsg(String msg){
        labMsg.setText(msg+"\r\n"+labMsg.getText());
    }
    CordovaWebView webView=new CordovaWebView() {
        @Override
        public void init(CordovaInterface cordova, List<PluginEntry> pluginEntries, CordovaPreferences preferences) {

        }

        @Override
        public boolean isInitialized() {
            return false;
        }

        @Override
        public View getView() {
            return null;
        }

        @Override
        public void loadUrlIntoView(String url, boolean recreatePlugins) {

        }

        @Override
        public void stopLoading() {

        }

        @Override
        public boolean canGoBack() {
            return false;
        }

        @Override
        public void clearCache() {

        }

        @Override
        public void clearCache(boolean b) {

        }

        @Override
        public void clearHistory() {

        }

        @Override
        public boolean backHistory() {
            return false;
        }

        @Override
        public void handlePause(boolean keepRunning) {

        }

        @Override
        public void onNewIntent(Intent intent) {

        }

        @Override
        public void handleResume(boolean keepRunning) {

        }

        @Override
        public void handleStart() {

        }

        @Override
        public void handleStop() {

        }

        @Override
        public void handleDestroy() {

        }

        @Override
        public void sendJavascript(String statememt) {

        }

        @Override
        public void showWebPage(String url, boolean openExternal, boolean clearHistory, Map<String, Object> params) {

        }

        @Override
        public boolean isCustomViewShowing() {
            return false;
        }

        @Override
        public void showCustomView(View view, WebChromeClient.CustomViewCallback callback) {

        }

        @Override
        public void hideCustomView() {

        }

        @Override
        public CordovaResourceApi getResourceApi() {
            return null;
        }

        @Override
        public void setButtonPlumbedToJs(int keyCode, boolean override) {

        }

        @Override
        public boolean isButtonPlumbedToJs(int keyCode) {
            return false;
        }

        @Override
        public void sendPluginResult(PluginResult cr, String callbackId)
        {
            Map<Integer,String> status=new HashMap<Integer,String>();
            status.put(0,"NO_RESULT");
            status.put(1,"OK");
            status.put(2,"CLASS_NOT_FOUND_EXCEPTION");
            status.put(3,"ILLEGAL_ACCESS_EXCEPTION");
            status.put(4,"INSTANTIATION_EXCEPTION");
            status.put(5,"MALFORMED_URL_EXCEPTION");
            status.put(6,"IO_EXCEPTION");
            status.put(7,"INVALID_ACTION");
            status.put(8,"JSON_EXCEPTION");
            status.put(9,"ERROR");

            addMsg(String.format("status:%s,message:%s",status.get(cr.getStatus()),cr.getMessage()));
        }

        @Override
        public PluginManager getPluginManager() {
            return null;
        }

        @Override
        public CordovaWebViewEngine getEngine() {
            return null;
        }

        @Override
        public CordovaPreferences getPreferences() {
            return null;
        }

        @Override
        public ICordovaCookieManager getCookieManager() {
            return null;
        }

        @Override
        public String getUrl() {
            return null;
        }

        @Override
        public Context getContext() {
            return null;
        }

        @Override
        public void loadUrl(String url) {

        }

        @Override
        public Object postMessage(String id, Object data) {
            return null;
        }
    };
}
